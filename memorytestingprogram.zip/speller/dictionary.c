// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <ctype.h>
#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
char *Word;
unsigned int sizeno;
const unsigned int N = 7500;

// Hash table
 node* table[N];
// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    // TODO
     int line = hash(word);
    node *n = table[line];
      if(n == NULL)
        {
         printf("check leak");
         return false;
        }
    while(n != NULL)
  {
    if(strcasecmp(n->word,word) == 0)
    {
        return true;
    }
    else
     {
         n = n->next;
     }
  }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    // TODOstackoverflow.com/questions/14409466/simple-hash-functions
    unsigned long hash = 5381;

     for (const char* ptr = word; *ptr != '\0'; ptr++)
     {
         hash = ((hash << 5) + hash) + tolower(*ptr);
     }

     return hash % N;
}

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
    // TODO
    FILE *speller = fopen(dictionary,"r");
    if(speller == NULL)
   {
     printf("input file can't be opened");
     return false;
   }
    Word = malloc(46*sizeof(char));

    while(fscanf(speller,"%s",Word) != EOF)
     {
         node *n = malloc(sizeof(node));
         if(n == NULL)
        {
         printf("input file cant be opened");
         return false;
        }
         strcpy(n->word , Word);
         int line = hash(Word);
          n->next = table[line];
          table[line] = n;
          sizeno = sizeno + 1;

     }
     fclose(speller);
    return true;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    // TODO
    return sizeno;
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    // TODO
    for(int i=0; i<N ; i++)
    {
        node *n = table[i];
         if(n == NULL)
        {
         printf("memory leakead");
         return false;
        }
        node *temp = n->next;
         if(temp == NULL)
        {
         printf("memory leak");
         return false;
        }
        free(n);
        n = temp;
        while(n != NULL)
        {
            temp = n->next;
            free(n);
            n = temp;
        }
    }
    free(Word);
    return true;
}
